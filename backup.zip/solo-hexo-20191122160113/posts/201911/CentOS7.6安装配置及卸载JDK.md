title: CentOS7.6安装、配置及卸载JDK
date: '2019-11-21 18:08:45'
updated: '2019-11-21 18:14:27'
tags: [CentOS, java]
permalink: /articles/2019/11/21/1574330925040.html
---
# 一、下载安装包

**a.   因为Java JDK区分32位和64位，所以安装之前需先判断一下我们操作系统为多少位·，命令如下：**

`uname -a`

解释：如果有x86_64就是64位的，没有就是32位的。后面是x686或x86_64则内核是64位的，i686或i386则内核是32位的。

**b.   下载JDK**
地址：http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html ,示例下载JDK8



# 二、安装Java JDK8.0


**a.   跳转到local下面创建自己的文件夹，kenceery（可自行命名）**


`a.1      cd /usr/local/`

`a.2      mkdir kencery`

`a.3      cd kencery/`


**b.   然后将下载了的JDK安装包复制到kencery文件夹下（可用cp命令或图形化操作）**




**c.   再将JDK解压，解压后重命名为javajdk**


`c.1   tar -zxv -f jdk-8u65-linux-i586.gz`

`c.2   mv jdk1.8.0_65 javajdk`

`c.3   cd javajdk`



**d.   通过上面步骤，JDK已经全部完成安装了，接下来就是更重要的一步：配置环境变量**



# 三、配置环境变量


**a.   在profile文件中添加java相关的环境变量**


`a.1   vim /etc/profile`
````
a.2   打开之后按键盘【i】键进入编辑模式，将下面的内容复制到底部：

JAVA_HOME=/usr/local/kencery/javajdk
PATH=$JAVA_HOME/bin:$PATH
CLASSPATH=$JAVA_HOME/jre/lib/ext:$JAVA_HOME/lib/tools.jar
export PATH JAVA_HOME CLASSPATH
注意：根据上面的配置信息，我们既可以将环境变量的配置完成，需要注意的是，PATH在配置的时候，一定要把JAVA_HOME/bin放在最前面，不然使用java命令时，系统会找到以前的java，再不往下找了，这样java这个可执行文件运行的目录其实不在$JAVA_HOME/bin下，而在其它目录下，会造成很大的问题。

````
`a.3 写完之后我们按键盘【ESC】按键退出，然后按【:wq】保存并关闭vim。`

**b.   配置完成后，最重要的一步就是使文件立即生效。命令如下：**

`source /etc/profile`



# 四、验证是否安装成功


**a.   上面所有的步骤完成之后，需要检查是否安装成功，输入如下命令：**


`a.1   java -version`

`a.2   echo $JAVA_HOME`



说明安装成功，环境变量也配置成功！


# 五、卸载Java JDK


说明：有时候安装失败或者要装新版本的JDK，可先卸载JDK：

**a.   首先执行命令查看服务器下的JDK的版本：命令如下：rpm -qa |grep jdk**

**b.   然后执行命令：yum -y remove java java-1.6.0-openjdk-1.6.0.0-1.50.1.11.5.el6_3.x86_64 将上面查询出来的每个版本依次删掉即可。**
