title: 我在 GitHub 上的开源项目
date: '2019-11-22 15:51:11'
updated: '2019-11-22 15:51:11'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [landlords](https://github.com/CherishVII/landlords) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/CherishVII/landlords/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/CherishVII/landlords/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/CherishVII/landlords/network/members "分叉数")</span>

斗地主



---

### 2. [Study-Workspace](https://github.com/CherishVII/Study-Workspace) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/CherishVII/Study-Workspace/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/CherishVII/Study-Workspace/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/CherishVII/Study-Workspace/network/members "分叉数")</span>

学习期间的所有项目代码



---

### 3. [Inventorymanagementsystem](https://github.com/CherishVII/Inventorymanagementsystem) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/CherishVII/Inventorymanagementsystem/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/CherishVII/Inventorymanagementsystem/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/CherishVII/Inventorymanagementsystem/network/members "分叉数")</span>

库存管理系统



---

### 4. [youji_Android](https://github.com/CherishVII/youji_Android) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/CherishVII/youji_Android/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/CherishVII/youji_Android/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/CherishVII/youji_Android/network/members "分叉数")</span>

a travle app

