title: CentOS7.6安装MySQL
date: '2019-11-21 16:39:05'
updated: '2019-11-21 16:39:05'
tags: [CentOS, MySQL]
permalink: /articles/2019/11/21/1574325545076.html
---
**一：去官网查看最新安装包**
https://dev.mysql.com/downloads/repo/yum/

**二：下载MySQL源安装包**

wget http://dev.mysql.com/get/mysql57-community-release-el7-11.noarch.rpm

安装MySql源

yum -y install mysql57-community-release-el7-11.noarch.rpm

查看一下安装效果

yum repolist enabled | grep mysql.*

**三：安装MySQL服务器**

yum install mysql-community-server

中间会弹出是与否的选择，选择y即可，然后耐心等待吧。。。。。。。

**四：启动MySQL服务**

systemctl start  mysqld.service

运行一下命令查看一下运行状态 

systemctl status mysqld.service

**五：初始化数据库密码**

查看一下初始密码

grep "password" /var/log/mysqld.log

登录

mysql -uroot -p

修改密码

ALTER USER 'root'@'localhost' IDENTIFIED BY '****************';

mysql默认安装了密码安全检查插件（validate_password），默认密码检查策略要求密码必须包含：大小写字母、数字和特殊符号，并且长度不能少于8位。否则会提示ERROR 1819 (HY000): Your password does not satisfy the current policy requirements错误

**六：数据库授权**

数据库没有授权，只支持localhost本地访问

`mysql>GRANT ALL PRIVILEGES ON *.* TO ``'root'``@``'%'` `IDENTIFIED BY ``'123456'` `WITH GRANT OPTION;`

`//``远程连接数据库的时候需要输入用户名和密码`

`用户名：root`

`密码:123456`

`指点ip:%代表所有Ip,此处也可以输入Ip来指定Ip`

`输入后使修改生效还需要下面的语句`

`mysql>FLUSH PRIVILEGES;`

  
也可以通过修改表来实现远程：

    mysql -u root -p

    mysql> use mysql; 
    mysql> update user set host = '%' where user = 'root'; 
    mysql> select host, user from user;

**七：设置自动启动**

systemctl enable mysqld

systemctl daemon-reload
