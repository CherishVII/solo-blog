title: CentOS7.6安装Tomcat
date: '2019-11-21 16:45:58'
updated: '2019-11-21 18:16:32'
tags: [CentOS, Tomcat]
permalink: /articles/2019/11/21/1574325958412.html
---
**1. 下载tomcat Linux安装包，地址：http://tomcat.apache.org/download-80.cgi , 我们下载的版本是8.0**

**2.因为tomcat的安装依赖于Java JDK，所以需要先判断Linux系统下面是否安装了JDK并配置了环境变量**

(1)  输入命令：`java -version` 如果显示JDK版本号，则证明已经安装了JDK。

(2)  输入命令：`echo $JAVA_HOME` 如果显示路径，则证明配置了环境变量。

如果输入上面两个命令，若有一个没有正确显示，则证明没有安装成功或没配置，请参考下面地址进行安装：<a href="http://cherishvii.com/articles/2019/11/21/1574330925040.html" target="_blank">CentOS7.6安装、配置及卸载JDK</a>

把解压好的tomcat放到服务器上这里我选择的是opt目录下

**3.给tomcat开放权限首先进入到opt文件中命令:`cd/opt`**

输入命令：`chmod -R 777 /opt/`

安装完成！

**4.配置80端口和域名：修改tomcat下conf里面的service.xml 文件8080端口修改为80**

配置域名：

**5.防火墙开放80端口**

先查看防火墙是否已经启动，命令：`firewall -cmd -state`

如果没有开启则使用命令开启防火墙


### 开启防火墙

`systemctl start firewall`

### 重启防火墙

`systemctl restart firewalld`

### 关闭防火墙

`systemctl stop firewalld`

开启防火墙后

### 开放80端口
`firewall-cmd --permanent --add-port=80/tcp`

查询端口是否开放
`firewall-cmd --query-port=80/tcp`

#重启防火墙(修改配置后要重启防火墙)
`firewall-cmd --reload`

### 启动tomcat

（1） 进入目录 cd /opt/tomcat/bin

（2） 之前启动可先关闭 ./shutdown.sh

（3） 输入命令启动 ./startup.sh

（4） 出现Tomcat首页即成功
