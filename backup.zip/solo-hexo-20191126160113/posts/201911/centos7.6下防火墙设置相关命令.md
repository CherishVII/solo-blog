title: centos7.6下防火墙设置相关命令
date: '2019-11-21 16:01:28'
updated: '2019-11-21 16:59:15'
tags: [CentOS, firewall, 防火墙]
permalink: /articles/2019/11/21/1574323288199.html
---
# 开启防火墙

`sudo systemctl start firewalld`

# 关闭防火墙

`sudo systemctl stop firewalld.service #关闭防火墙`  
`sudo systemctl disable firewalld.service #取消开机启动`

# 查看firewall服务状态

`systemctl status firewalld`

# 查看firewall的状态

`firewall-cmd --state`

# 查看防火墙规则

`firewall-cmd --list-all`  
或者直接查看配置文件  
`vim /etc/firewalld/zones/public.xml`

# 查询端口是否开放

`firewall-cmd --query-port=8080/tcp`

# 添加端口

`firewall-cmd --permanent --add-port=8080/tcp # --permanent：表示设置为持久`  
`firewall-cmd --permanent --add-port=8080/udp`

# 移除端口

`firewall-cmd --permanent --remove-port=8080/tcp`  
`firewall-cmd --permanent --remove-port=8080/udp`

# 重启防火墙`(修改配置后要重启防火墙)`

`firewall-cmd --reload`
